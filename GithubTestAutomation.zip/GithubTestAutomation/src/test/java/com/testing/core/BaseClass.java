package com.testing.core;

import org.openqa.selenium.WebDriver;

public class BaseClass {
	protected static WebDriver driver = null;
}
